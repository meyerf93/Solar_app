console.log("[browser-js] Loading client.js...");

window.addEventListener('onUnityReady', function (e) { 
	console.log("[browser-js] Received 'onUnityReady' JS event.");

	var name = 'Anonymous-' + Math.floor((Math.random() * 1000000) + 1);
	var message = 'Hello!';
	var nameButton = document.getElementById('name');
	var messageButton = document.getElementById('message');

	nameButton.addEventListener('click', function() {
		var nameCache = name;
		name = window.prompt('Your Name', name);
		if(nameCache!=name) {
			SendMessage('MyGame', 'onChatMessage', JSON.stringify({ type: 'namechange', username: name, message: nameCache}));
		}
	});

	messageButton.addEventListener('click', function() {
		message = window.prompt('Your Message', message);
		SendMessage('MyGame', 'onChatMessage', JSON.stringify({ type: 'conversation', username: name, message: message}));
	});

	SendMessage('MyGame', 'onUnityReady', JSON.stringify({ username: name }))

	geolocator.config({
	    language: "en",
	    google: {
	        version: "3",
	        key: "AIzaSyB1FMzOxifHhBB5GxroamCbye4j8EW5zYg"
	    }
	});

	var options = {
	    enableHighAccuracy: true,
	    timeout: 6000,
	    maximumAge: 0,
	    desiredAccuracy: 30,
	    fallbackToIP: true // fallback to IP if Geolocation fails or rejected
	    //addressLookup: true,
	    //timezone: true,
	    //map: "map-canvas"
	};

	geolocator.locate(options, function (err, location) {
	    if (err) return console.log(err);
	    console.log(location);
	    SendMessage('MyGame', 'onTriangulated', JSON.stringify({ accuracy: location.coords.accuracy, longitude: location.coords.longitude, latitude: location.coords.latitude }))
	});
});